test = {
  'name': 'Python Basics',
  'points': 0,
  'suites': [
    {
      'type': 'wwpp',
      'cases': [
        {
          'code': """
          >>> x = 20
          >>> x + 2
          22
          >>> x
          20
          >>> y = 5
          >>> y = y + 3
          >>> y * 2
          16
          >>> y + x
          28
          """,
        },
      ]
    }
  ]
}